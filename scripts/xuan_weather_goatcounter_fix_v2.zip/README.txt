# GoatCounter visitor statistics fix v2

Replace `scripts/update_goatcounter_stats.py` in the repository with the version in this package.

Important:
- The official endpoint is `/api/v0/stats/total` (singular), not `/stats/totals`.
- Keep `GOATCOUNTER_API_TOKEN` in GitHub repository Actions secrets only.
- Do not paste the token into source files or chat.
- This script has not been tested against the account's private token; rerun the GitHub Actions workflow to verify.
